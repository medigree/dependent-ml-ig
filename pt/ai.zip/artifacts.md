# Resumen de Artefactos - v0.1.0

## Resumen de Artefactos

 There is no translation page available for the current page, so it has been rendered in the default language 

